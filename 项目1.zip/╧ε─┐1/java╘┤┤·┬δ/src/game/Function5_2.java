package game;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


/**
 * ͳ���ı��е��ʳ��ֵĴ��� ���ļ���ʽ���
 * @author lyd
 *
 */
public class Function5_2 {
	
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		
		//1.����conf���󣬲�����hdfs·��
		//2.����job������job���������� Jar map reduce reduce���������(key value) �����ʽ����ʽ
		//�ļ�����������·��  ϵͳ�˳�
		Configuration conf = new Configuration();
		conf.set("fs.defaultFS", "hdfs://master:9000");
		
		Job job = Job.getInstance(conf, "function5-2");
		job.setJarByClass(Function5_2.class);
		
		job.setMapperClass(MyMapper.class);
		job.setReducerClass(MyReducer.class);
		
		job.setSortComparatorClass(mysort.class);
		job.setGroupingComparatorClass(mysort.class);
		
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(NullWritable.class);
		
		job.setInputFormatClass(TextInputFormat.class);
		
		FileInputFormat.addInputPath(job, new Path("/test/output/game5/game5.1"));
		Path outputPath = new Path("/test/output/game5/game5.2");
		FileSystem.get(conf).delete(outputPath, true);
		FileOutputFormat.setOutputPath(job, outputPath);
		System.exit(job.waitForCompletion(true)?0:1);
		
		
	}
	
  
	public static class MyMapper extends Mapper<LongWritable, Text, Text, NullWritable>{
		
		@Override
		protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text, NullWritable>.Context context)
				throws IOException, InterruptedException {
			
				context.write(value, NullWritable.get());	
			
		}
		
	}
	
    /**
     * @author lyd
     * @version 1.0
     * @param KEYIN
     *            ��k2 ��ʾÿһ���е�ÿ������
     * @param VALUEIN
     *            ��v2 ��ʾÿһ���е�ÿ�����ʵĳ��ִ������̶�ֵΪ1
     * @param KEYOUT
     *            ��k3 ��ʾÿһ���е�ÿ������
     * @param VALUEOUT
     *            ��v3 ��ʾÿһ���е�ÿ�����ʵĳ��ִ���֮��
     */
	public static class MyReducer extends Reducer<Text, NullWritable, Text, NullWritable>{
		int sum = 0;
		@Override
		protected void reduce(Text value, Iterable<NullWritable> iterable,
				Reducer<Text, NullWritable, Text, NullWritable>.Context context) throws IOException, InterruptedException {
			sum++;
			if (sum<=20) {
				context.write(value, NullWritable.get());
			}
		}
	}
	public  static class mysort extends WritableComparator  {
		
		public mysort() {
			super(Text.class,true);
		}

		@Override
		public int compare(WritableComparable a, WritableComparable b) {
			
			Text aText = (Text) a;
			Text bText = (Text) b;
			Integer a1 = Integer.parseInt(aText.toString().split("\\s+")[1]);
			Integer a2 = Integer.parseInt(aText.toString().split("\\s+")[2]);
			
			Integer b1 = Integer.parseInt(bText.toString().split("\\s+")[1]);
			Integer b2 = Integer.parseInt(bText.toString().split("\\s+")[2]);
			
			String a3 = aText.toString().split("\\s+")[3];
			String b3 = bText.toString().split("\\s+")[3];
			
			return b1.compareTo(a1)==0?b2.compareTo(a2)==0?b3.compareTo(a3):b2.compareTo(a2):b1.compareTo(a1);
		}
		
	}

}

