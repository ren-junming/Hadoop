//堆叠区域图
(function(){
	
	var iosa = echarts.init(document.getElementById("iosa"));
	
	option = {
    title: {
        text: '每日用户对比'
    },
    tooltip : {
        trigger: 'axis'
    },
    legend: {
        data:['ios','andriod']
    },
    toolbox: {
        feature: {
            saveAsImage: {}
        }
    },
    grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
    },
    xAxis : [
        {
            type : 'category',
            boundaryGap : false,
            data : ['1.1','1.2','1.3','1.4','1.5','1.6','1.7']
        }
    ],
    yAxis : [
        {
            type : 'value'
        }
    ],
    series : [
        {
            name:'ios',
            type:'line',
            stack: '总量',
            areaStyle: {normal: {}},
            data:[7820,9782,10809,11503,14149,18352,17373]
        },
        {
            name:'andriod',
            type:'line',
            stack: '总量',
            areaStyle: {normal: {}},
            data:[3256,4148,4585,4868,5995,7807,7390]
        }
    ]
};

iosa.setOption(option);
})();