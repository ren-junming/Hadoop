package game;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 * ͳ���ı��е��ʳ��ֵĴ��� ���ļ���ʽ���
 * @author lyd
 *
 */
public class Function6 {
	
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		
		//1.����conf���󣬲�����hdfs·��
		//2.����job������job���������� Jar map reduce reduce���������(key value) �����ʽ����ʽ
		//�ļ�����������·��  ϵͳ�˳�
		Configuration conf = new Configuration();
		conf.set("fs.defaultFS", "hdfs://master:9000");
		
		Job job = Job.getInstance(conf, "wordcount");
		job.setJarByClass(Function6.class);
		
		job.setMapperClass(Function6Mapper.class);
		job.setReducerClass(Function6Reducer.class);
		
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
		
		job.setInputFormatClass(KeyValueTextInputFormat.class);
		
		FileInputFormat.addInputPath(job, new Path("/test/input/game.log"));
		Path outputPath = new Path("/test/output/game6");
		FileSystem.get(conf).delete(outputPath, true);
		FileOutputFormat.setOutputPath(job, outputPath);
		System.exit(job.waitForCompletion(true)?0:1);
		
		
	}
	
 
	public static class Function6Mapper extends Mapper<Text, Text, Text, Text>{
		
		@Override
		protected void map(Text key, Text value, Mapper<Text, Text, Text, Text>.Context context)
				throws IOException, InterruptedException {
			
			String word =value.toString().split("\\s+")[2].split("T")[0].split("-")[2];
			Text text = new Text();
			text.set(word);
			context.write(key, text);
			}
			
		}
		
	
  
	public static class Function6Reducer extends Reducer<Text, Text, Text, IntWritable>{
		
		@Override
		protected void reduce(Text value, Iterable<Text> iterable,
				Reducer<Text, Text, Text, IntWritable>.Context context) throws IOException, InterruptedException {
			
			int t = 0;
			Set<String> set = new HashSet<String>();
			
			for (Text text : iterable) {
				String status = text.toString();
				set.add(status);
			}
			if (set.contains("01")) {
				t=1;
			}
			if (set.contains("02")) {
				t=10+t;
			}
			if (set.contains("03")) {
				t=100+t;
			}
			if (set.contains("04")) {
				t=1000+t;
			}
			if (set.contains("05")) {
				t=10000+t;
			}
			if (set.contains("06")) {
				t=100000+t;
			}
			if (set.contains("07")) {
				t=1000000+t;
			}
			
			IntWritable i = new IntWritable();
			i.set(t);
			
			context.write(value, i);
		}
		
	}
}
	


