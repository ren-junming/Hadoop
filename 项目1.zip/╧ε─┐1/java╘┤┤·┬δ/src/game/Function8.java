package game;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Function8 {
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		
		Configuration conf = new Configuration();
		conf.set("fs.defaultFS", "hdfs://master:9000");

		Job job = Job.getInstance(conf, "function8");
		job.setJarByClass(Function8.class);

		job.setMapperClass(Function8Mapper.class);  //�˴���������Mapper�� �����mapper��������һ��
		job.setReducerClass(Function8Reducer.class);//�˴���������Reducer�� �����Reducer��������һ��

		job.setMapOutputKeyClass(Text.class);   //ָ��map�������������key===������������
		job.setMapOutputValueClass(Text.class);

		job.setOutputKeyClass(Text.class);  //ָ�� reduc��������� key===������������
		job.setOutputValueClass(NullWritable.class);//ָ�� reduc���������value===�����ĸ�����

		job.setInputFormatClass(KeyValueTextInputFormat.class);

		Path path1 = new Path("/test/input/game.log");
		FileInputFormat.addInputPath(job,path1);

		Path outPath = new Path("/test/output/game8/");
		FileSystem.get(conf).delete(outPath, true);  //���Ŀ¼���ڣ���ɾ��
		FileOutputFormat.setOutputPath(job, outPath);

		System.exit(job.waitForCompletion(true)?0:1);
	}
	
	public static class Function8Mapper extends Mapper<Text, Text, Text, Text>{

		@Override
		protected void map(Text key, Text value,Context context)
				throws IOException, InterruptedException {

			Text t =new Text();
			t.set(value.toString().split("\\s+")[2].split("T")[0].split("-")[2]);
			context.write(key,t);	
		}
	}
	
	public static class Function8Reducer extends Reducer<Text, Text, Text, NullWritable>{
		
		Text t = new Text();
		private int day3Total;//��ʹ�õ�����
		
		@Override
		protected void reduce(Text key, Iterable<Text> values,Context context)
				throws IOException, InterruptedException {
			
			boolean fDay = false;
			boolean sDay = false;
			boolean tDay = false;
			
			for (Text value : values) {
				String status = value.toString();
				if (status.equals("01")) {
					fDay = true;
				}else if (status.equals("02")) {
					sDay = true;
				}else if (status.equals("03")) {
					tDay = true;
				}
			}
			
			if (fDay || sDay || tDay){
				day3Total++;
			}
		}
		
		@Override
		protected void cleanup(Context context)
				throws IOException, InterruptedException {
					
			t.set("threeRate:"+day3Total);
			context.write(t, NullWritable.get());
			
		}
		
	}
}
