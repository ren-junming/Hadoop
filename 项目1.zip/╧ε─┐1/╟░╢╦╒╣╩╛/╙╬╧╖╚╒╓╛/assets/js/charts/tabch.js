(function(){

var tabc = echarts.init(document.getElementById("tabc"));

option = {
    title: {
        text: '堆叠区域图'
    },
    tooltip : {
        trigger: 'axis',
        axisPointer: {
            type: 'cross',
            label: {
                backgroundColor: '#6a7985'
            }
        }
    },
    legend: {
        data:['登录次数','在线时长']
    },
    toolbox: {
        feature: {
            saveAsImage: {}
        }
    },
    grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
    },
    xAxis : [
        {
            type : 'category',
            boundaryGap : false,
            data : ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20']
        }
    ],
    yAxis : [
        {
            type : 'value'
        }
    ],
    series : [
        {
            name:'在线时间',
            type:'line',
            stack: '总量',
            areaStyle: {},
            data:[150,149,148,148,148, 147, 147,147,147,146,146,146, 146,146, 146, 145, 145,145, 144, 144]
        },
        {
            name:'登录次数',
            type:'line',
            stack: '总量',
            areaStyle: {},
            data:[21,24,30,21,21,15,12,13,15,14,11,19,17,12,10,21,13,22,10,15]
        }
    ]
};

tabc.setOption(option);
})();