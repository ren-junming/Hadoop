package game;

import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Function2 {

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		
		Configuration conf = new Configuration();
		conf.set("fs.defaultFS", "hdfs://master:9000");
		
		Job job = Job.getInstance(conf, "function2");
		job.setJarByClass(Function2.class);
		
		job.setMapperClass(Function2Mapper.class);  //�˴���������Mapper�� �����mapper��������һ��
		job.setReducerClass(Function2Reducer.class);//�˴���������Reducer�� �����Reducer��������һ��
		
		
		job.setOutputKeyClass(Text.class);  //ָ�� reduc��������� key===������������
		job.setOutputValueClass(NullWritable.class);//ָ�� reduc���������value===�����ĸ�����
		
		job.setPartitionerClass(Mypartition.class);
		job.setNumReduceTasks(7);
		
		job.setInputFormatClass(TextInputFormat.class);
		
		FileInputFormat.addInputPath(job, new Path("/test/input/game.log"));
		
		Path outPath = new Path("/test/output/game2/");
		FileSystem.get(conf).delete(outPath, true);  //���Ŀ¼���ڣ���ɾ��
		FileOutputFormat.setOutputPath(job, outPath);
		
		System.exit(job.waitForCompletion(true)?0:1);
	}
	
	public static class Function2Mapper extends Mapper<LongWritable, Text, Text, NullWritable>{
		
		@Override
		protected void map(LongWritable key, Text value,Context context)
				throws IOException, InterruptedException {
			context.write(value, NullWritable.get());	
		}
	}
	
	public static class Function2Reducer extends Reducer<Text, NullWritable, Text, NullWritable>{
		@Override
		protected void reduce(Text test, Iterable<NullWritable> values,
				Context context) throws IOException, InterruptedException {
			
			for (NullWritable iNullWritable : values) {
				context.write(test, iNullWritable.get());
			}
		}
	}
	
	public static class Mypartition extends Partitioner<Text, NullWritable>  {

		@Override
		public int getPartition(Text test, NullWritable values, int numPartition) {
			
			String m = test.toString().split("\\s+")[3];
			String u = m.split("T")[0];
			
			if (u.equals("2017-01-01")){
				return 0;
			} else if(u.equals("2017-01-02")){
				return 1;
			}else if(u.equals("2017-01-03")){
				return 2;
			}else if(u.equals("2017-01-04")){
				return 3;
			}else if(u.equals("2017-01-05")){
				return 4;
			}else if(u.equals("2017-01-06")){
				return 5;
			}else{
				return 6;
			}
		
		}
	}
}
